import os
import time
import shutil
import json
from getpass import getpass
from PIL import Image
import subprocess
import platform

# Version number string
VersionNumber = "0.2"
userdata_file = 'userdata.txt'
config_file = 'config.json'

# Default configuration settings
default_config = {
    "Loading Bar": "Y",
    "Credentials": "Y",
    "Goodbye Message": "Y"
}

# Load configuration settings
def load_config():
    if os.path.exists(config_file):
        with open(config_file, 'r') as file:
            return json.load(file)
    else:
        with open(config_file, 'w') as file:
            json.dump(default_config, file, indent=4)
        return default_config

config = load_config()

# Save configuration settings
def save_config():
    with open(config_file, 'w') as file:
        json.dump(config, file, indent=4)

# Fake OS boot sequence with loading bar
def boot_sequence():
    os.system('clear')
    print(f"Booting 4CDOS Version {VersionNumber}")
    if config["Loading Bar"] == "Y":
        loading_bar = "[                    ]"
        for i in range(1, 21):
            time.sleep(0.25)
            loading_bar = loading_bar[:i] + "#" + loading_bar[i+1:]
            print(f"\r{loading_bar}", end="", flush=True)
    print(f"\n4CDOS Version {VersionNumber} loaded successfully.")

def create_user():
    print("Welcome to 4CDOS! Please create your username and password.")
    username = input("Enter a username: ")
    password = getpass("Enter a password: ")
    with open(userdata_file, 'w') as f:
        f.write(f"{username}\n{password}")
    print("User created successfully!")

def authenticate():
    if config["Credentials"] == "N":
        return True
    if not os.path.exists(userdata_file):
        create_user()
    
    print("Please log in.")
    username = input("Username: ")
    password = getpass("Password: ")
    
    with open(userdata_file, 'r') as f:
        stored_username, stored_password = f.read().splitlines()
        
    if username == stored_username and password == stored_password:
        print("Login successful!")
        return True
    else:
        print("Invalid username or password.")
        return False

# Custom command functions
def nav(directory):
    try:
        os.chdir(directory)
        print(f"Changed directory to {directory}")
    except FileNotFoundError:
        print(f"Directory {directory} not found")

def navback():
    os.chdir("..")
    print("Moved back to parent directory")

def makefolder(directory):
    try:
        os.mkdir(directory)
        print(f"Created directory {directory}")
    except FileExistsError:
        print(f"Directory {directory} already exists")

def deletefolder(directory):
    try:
        shutil.rmtree(directory)
        print(f"Deleted directory {directory}")
    except FileNotFoundError:
        print(f"Directory {directory} not found")

def deletefile(file):
    try:
        os.remove(file)
        print(f"Deleted file {file}")
    except FileNotFoundError:
        print(f"File {file} not found")

def list_dir():
    for item in os.listdir():
        print(item)

def listfolder():
    print(os.getcwd())

def clear():
    os.system('clear')

def exit_os():
    if config["Goodbye Message"] == "Y":
        print(f"Closing 4CDOS Version {VersionNumber}")
        time.sleep(1)
    exit()

def help():
    print(
        "nav <folder> - navigates to folder\n"
        "navback - goes back a folder\n"
        "makefolder <folder> - creates a folder\n"
        "deletefolder <folder> - deletes a folder\n"
        "deletefile <file> - deletes a file\n"
        "list - lists all folders and apps in folder\n"
        "listfolder - lists the location of the current folder\n"
        "help - lists available commands\n"
        "clear - clears 4CDOS\n"
        "exit - closes 4CDOS\n"
        "img <image.extension> - opens an image\n"
        "video <video.extension> - opens a video\n"
        "copy <source> <destination> - copies a file or folder\n"
        "move <source> <destination> - moves a file or folder\n"
        "rename <old_name> <new_name> - renames a file or folder\n"
        "text <file> - displays the contents of a text file\n"
        "edittext <file> - opens a text file for editing\n"
        "makeempty <file> - creates an empty file\n"
        "diskusage - shows the disk usage of the current directory\n"
        "diskusagefile <file> - shows the disk usage of a file\n"
        "systeminfo - displays basic system information\n"
        "networkstatus - checks the network status\n"
        "find <name> - searches for files or directories\n"
        "history - shows a list of executed commands\n"
        "date - displays the current date and time\n"
        "config4cdos - changes configuration settings for 4CDOS"
    )

def img(image_path):
    try:
        with Image.open(image_path) as img:
            img.show()
    except FileNotFoundError:
        print(f"Image {image_path} not found")
    except Exception as e:
        print(f"Error opening image: {e}")

def video(video_path):
    try:
        subprocess.run(['xdg-open', video_path], check=True)
    except FileNotFoundError:
        print(f"Video {video_path} not found")
    except Exception as e:
        print(f"Error opening video: {e}")

def copy(src, dst):
    try:
        if os.path.isdir(src):
            shutil.copytree(src, dst)
        else:
            shutil.copy(src, dst)
        print(f"Copied {src} to {dst}")
    except FileNotFoundError:
        print(f"{src} not found")

def move(src, dst):
    try:
        shutil.move(src, dst)
        print(f"Moved {src} to {dst}")
    except FileNotFoundError:
        print(f"{src} not found")

def rename(old_name, new_name):
    try:
        os.rename(old_name, new_name)
        print(f"Renamed {old_name} to {new_name}")
    except FileNotFoundError:
        print(f"{old_name} not found")

def text(file_path):
    try:
        with open(file_path, 'r') as file:
            print(file.read())
    except FileNotFoundError:
        print(f"File {file_path} not found")

def edittext(file_path):
    try:
        subprocess.run(['nano', file_path])
    except FileNotFoundError:
        print(f"File {file_path} not found")
    except Exception as e:
        print(f"Error opening file for editing: {e}")

def makeempty(file_path):
    try:
        with open(file_path, 'a'):
            os.utime(file_path, None)
        print(f"Created empty file {file_path}")
    except Exception as e:
        print(f"Error creating file: {e}")

def diskusage():
    usage = shutil.disk_usage(os.getcwd())
    print(f"Total: {usage.total} bytes")
    print(f"Used: {usage.used} bytes")
    print(f"Free: {usage.free} bytes")

def diskusagefile(file_path):
    try:
        size = os.path.getsize(file_path)
        print(f"File size: {size} bytes")
    except FileNotFoundError:
        print(f"File {file_path} not found")

def systeminfo():
    print(f"System: {platform.system()}")
    print(f"Node Name: {platform.node()}")
    print(f"Release: {platform.release()}")
    print(f"Version: {platform.version()}")
    print(f"Machine: {platform.machine()}")
    print(f"Processor: {platform.processor()}")

def networkstatus():
    try:
        response = subprocess.run(['ping', '-c', '1', 'google.com'], stdout=subprocess.PIPE)
        if response.returncode == 0:
            print("Network is up")
        else:
            print("Network is down")
    except Exception as e:
        print(f"Error checking network status: {e}")

def find(name):
    for root, dirs, files in os.walk('.'):
        if name in files or name in dirs:
            print(os.path.join(root, name))

def history():
    for cmd in command_history:
        print(cmd)

def date():
    print(time.strftime("%Y-%m-%d %H:%M:%S"))

def config4cdos():
    print("Configure 4CDOS")
    for setting in config:
        new_value = input(f"{setting} (current: {config[setting]}) [Y/N]: ").upper()
        if new_value in ['Y', 'N']:
            config[setting] = new_value
    save_config()
    print("Configuration updated.")

# Command history
command_history = []

# Command dispatcher
commands = {
    'nav': nav,
    'navback': navback,
    'makefolder': makefolder,
    'deletefolder': deletefolder,
    'deletefile': deletefile,
    'list': list_dir,
    'listfolder': listfolder,
    'clear': clear,
    'exit': exit_os,
    'help': help,
    'img': img,
    'video': video,
    'copy': copy,
    'move': move,
    'rename': rename,
    'text': text,
    'edittext': edittext,
    'makeempty': makeempty,
    'diskusage': diskusage,
    'diskusagefile': diskusagefile,
    'systeminfo': systeminfo,
    'networkstatus': networkstatus,
    'find': find,
    'history': history,
    'date': date,
    'config4cdos': config4cdos
}

if __name__ == "__main__":
    boot_sequence()
    if authenticate():
        while True:
            command_input = input("4CDOS> ").strip()
            if command_input:
                command_history.append(command_input)
                parts = command_input.split()
                command = parts[0].lower()
                args = parts[1:]
                if command in commands:
                    try:
                        commands[command](*args)
                    except TypeError:
                        print(f"Invalid arguments for {command}")
                else:
                    print(f"Unknown command: {command}")
